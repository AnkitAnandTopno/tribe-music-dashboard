import { createActions, handleActions } from "redux-actions";
import _ from "lodash";
const defaultState = {
  songs: []
};

export const { addSong, setSongs, editSong } = createActions({
  ADD_SONG: song => song,
  SET_SONGS: song => song,
  EDIT_SONG: song => song
});

// Reducer
const reducer = handleActions(
  {
    ADD_SONG: (state, action) => {
      let newSong = _.cloneDeep(state.songs);
      newSong.push(action.payload);
      return _.assign({}, state, { songs: newSong });
    },
    SET_SONGS: (state, action) => {
      return _.assign({}, state, { songs: action.payload });
    },
    EDIT_SONG: (state, action) => {
      let newSong = _.cloneDeep(state.songs);
      newSong[action.payload.index] = action.payload.event;
      return _.assign({}, state, { songs: newSong });
    }
  },
  defaultState
);
export default reducer;

export const getSongs = state => state.songs.songs;
