import React, { Component } from "react";
import {
  Col,
  Row,
  Form,
  FormGroup,
  Label,
  Input,
  Modal,
  Progress
} from "reactstrap";
import { connect } from "react-redux";
import _ from "lodash";
import { withRouter } from "react-router-dom";
import Button from "components/CustomButtons/Button.js";
import SimpleIcon from "components/simpleIcon/simpleIcon.js";
import SelectorInput from "components/CustomInput/selectorInput.js";
import Uploader from "components/CustomInput/uploader";
import CustomInput from "components/CustomInput/CustomInput";
import GridContainer from "components/Grid/GridContainer";
import GridItem from "components/Grid/GridItem";
import CustomCheckbox from "components/CustomInput/CustomCheckbox";
import { Checkbox, CircularProgress } from "@material-ui/core";
import { sendRequest } from "utills/util";
import { itemApi } from "constant/api";
import Cookies from "universal-cookie";

const cookies = new Cookies();

//regex - ([S|M|K|B|Sa|E]\s)?[0-9]+
class AddItemForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      altName: undefined,
      inventory: 0,
      imageUrls: [""],
      name: undefined,
      category: "fruit",
      isFeatured: false,
      price: 0,
      unit: "1 kg",
      discount: 0, //percentage
      emptyFields: {
        name: { empty: true, prestine: true },
        imageUrls: { empty: true, prestine: true }
      }
    };
  }
  isEmpty(type, id, value) {
    let newEmptyFields = _.cloneDeep(this.state.emptyFields);
    newEmptyFields[id].prestine = false;
    switch (type) {
      case "array":
        if (value[0] === "") {
          newEmptyFields[id].empty = true;
        } else {
          newEmptyFields[id].empty = false;
        }
        break;
      case "string":
        if (value === "") {
          newEmptyFields[id].empty = true;
        } else {
          newEmptyFields[id].empty = false;
        }
        break;
    }

    this.setState({ emptyFields: newEmptyFields });
  }
  submit = () => {
    let checkState = _.cloneDeep(this.state);
    checkState = _.omit(checkState, ["emptyFields", "isLoading"]);
    if (
      _.filter(this.state.emptyFields, (value, key) => value.empty).length > 0
    ) {
      alert("Some Fields Seems Empty. Please Check.");
    } else {
      this.setState({ isLoading: true });
      const thenFn = res => {
        this.setState({
          altName: undefined,
          inventory: 0,
          imageUrls: [""],
          name: undefined,
          category: "fruit",
          isFeatured: false,
          price: 0,
          unit: "1 kg",
          discount: 0, //percentage
          emptyFields: {
            name: { empty: true, prestine: true },
            imageUrls: { empty: true, prestine: true }
          },
          isLoading: false
        });
      };
      const errorFn = () => {
        this.setState({ isLoading: false });
        alert("Something went wrong. Please try again later.");
      };
      sendRequest(itemApi.addItem, {
        item: checkState,
        success: { fn: thenFn },
        errorFn: { fn: errorFn }
      });
    }
  };

  submitUpdate = () => {
    let { match, history } = this.props;
    let id = match && match.params && match.params.id;
    let checkState = _.cloneDeep(this.state);
    checkState = _.omit(checkState, ["emptyFields", "isLoading"]);
    if (
      _.filter(this.state.emptyFields, (value, key) => value.empty).length > 0
    ) {
      alert("Some Fields Seems Empty. Please Check.");
    } else {
      this.setState({ isLoading: true });
      const thenFn = res => {
        this.setState({
          altName: undefined,
          inventory: 0,
          imageUrls: [""],
          name: undefined,
          category: "fruit",
          isFeatured: false,
          price: 0,
          unit: "1 kg",
          discount: 0, //percentage
          emptyFields: {
            altName: { empty: true, prestine: true },
            name: { empty: true, prestine: true },
            imageUrls: { empty: true, prestine: true }
          },
          isLoading: false
        });
        history.push("/admin/itemList");
      };
      const errorFn = () => {
        this.setState({ isLoading: false });
        alert("Something went wrong. Please try again later.");
      };
      sendRequest(itemApi.updateItem, {
        id,
        item: checkState,
        success: { fn: thenFn },
        errorFn: { fn: errorFn }
      });
    }
  };
  componentDidMount() {
    let { match } = this.props;
    let id = match && match.params && match.params.id;
    if (id) {
      this.setState({ isLoading: true });
      const thenFn = res => {
        let { data } = res;
        this.setState({
          ...data,
          isLoading: false,
          emptyFields: {
            name: { empty: false, prestine: true },
            imageUrls: { empty: false, prestine: true }
          }
        });
      };
      const errorFn = error => {
        this.setState({ isLoading: false });
        alert("Something went wrong. Please try again later.");
      };
      sendRequest(itemApi.getItems, {
        success: { fn: thenFn },
        error: { fn: errorFn },
        id,
        distributorId: cookies.get("distributorId")
      });
    }
  }
  render() {
    const { imageUrls, emptyFields, isLoading } = this.state;
    let { match } = this.props;
    let id = match && match.params && match.params.id;
    return (
      <div
        style={{
          background: "#fff",
          padding: 10
        }}
      >
        {isLoading ? (
          <CircularProgress color="secondary" />
        ) : (
          <Form>
            <FormGroup>
              <GridContainer>
                <GridItem>
                  <CustomInput
                    labelText="Item Name"
                    id="itemName"
                    formControlProps={{
                      fullWidth: true
                    }}
                    inputProps={{
                      value: this.state.name,
                      onChange: e => {
                        this.setState({
                          name: e.target.value
                        });
                        this.isEmpty("string", "name", e.target.value);
                      }
                    }}
                    error={!emptyFields.name.prestine && emptyFields.name.empty}
                  />
                </GridItem>
                <GridItem>
                  <CustomInput
                    labelText="Alternative Item Name"
                    id="altItemName"
                    formControlProps={{
                      fullWidth: true
                    }}
                    inputProps={{
                      value: this.state.altName,
                      onChange: e => {
                        this.setState({
                          altName: e.target.value
                        });
                      }
                    }}
                  />
                </GridItem>
                <GridItem>
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <Checkbox
                      checked={this.state.isFeatured}
                      onClick={() => {
                        this.setState({
                          isFeatured: !this.state.isFeatured
                        });
                      }}
                    />
                    <span>Is it Featured?</span>
                  </div>
                </GridItem>
              </GridContainer>
            </FormGroup>
            <FormGroup>
              <GridContainer>
                <GridItem>
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <SimpleIcon iconName="mdi-currency-inr" iconColor="gray" />
                    <CustomInput
                      labelText="Price Per Unit"
                      id="price"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        type: "number",
                        value: this.state.price,
                        onChange: e => {
                          this.setState({
                            price: e.target.value
                          });
                        }
                      }}
                    />
                  </div>
                </GridItem>
                <GridItem>
                  <SelectorInput
                    label="Unit"
                    options={[
                      { value: "1 kg", name: "1 kg" },
                      { value: "500 g", name: "500 g" },
                      { value: "250 g", name: "250 g" },
                      { value: "1 piece", name: "1 piece" }
                    ]}
                    onChange={value => {
                      this.setState({ unit: value });
                    }}
                    value={this.state.unit}
                  />
                </GridItem>
              </GridContainer>
            </FormGroup>
            <FormGroup>
              <GridContainer>
                <GridItem>
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <CustomInput
                      labelText="Discount(in %)"
                      id="discount"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        type: "number",
                        value: this.state.discount,
                        onChange: e => {
                          this.setState({
                            discount: e.target.value
                          });
                        }
                      }}
                    />
                    <SimpleIcon iconName="mdi-percent" iconColor="gray" />
                  </div>
                </GridItem>
              </GridContainer>
            </FormGroup>
            <FormGroup>
              <GridContainer>
                <GridItem>
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <CustomInput
                      labelText="Number of Units We have."
                      id="inventory"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        type: "number",
                        value: this.state.inventory,
                        onChange: e => {
                          this.setState({
                            inventory: e.target.value
                          });
                        }
                      }}
                    />
                  </div>
                </GridItem>
              </GridContainer>
            </FormGroup>
            <FormGroup>
              <SelectorInput
                label="Category"
                options={[
                  { value: "fruit", name: "Fruit" },
                  { value: "veggies", name: "Veggies" },
                  { value: "cooking", name: "Cooking" },
                  { value: "healthcare", name: "Healthcare" },
                  { value: "homecare", name: "Homecare" },
                  { value: "others", name: "Others" }
                ]}
                onChange={value => {
                  this.setState({ category: value });
                }}
                value={this.state.category}
              />
            </FormGroup>
            <FormGroup>
              <Label>Images</Label>
              {!emptyFields.imageUrls.prestine &&
              emptyFields.imageUrls.empty ? (
                <span style={{ color: "red" }}>
                  First Image cannot be empty
                </span>
              ) : null}
              {_.map(imageUrls, (item, index) => (
                <div
                  key={"key" + index}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    border: "1px solid #ddd",
                    padding: 10
                  }}
                >
                  <Uploader
                    value={item}
                    onChange={link => {
                      let newImageUrls = _.cloneDeep(imageUrls);
                      newImageUrls[index] = link;
                      // console.log("link", link);
                      if (link && link === "") {
                      } else {
                        if (index == imageUrls.length - 1)
                          newImageUrls.push("");
                      }
                      this.setState({ imageUrls: newImageUrls });
                      this.isEmpty("array", "imageUrls", newImageUrls);
                    }}
                  />
                </div>
              ))}
            </FormGroup>

            <div>
              <Button
                color={"primary"}
                onClick={() => (id ? this.submitUpdate() : this.submit())}
              >
                {id ? "Update Item" : "Add Item"}
              </Button>
            </div>
          </Form>
        )}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {};
};
const mapDispatchToProps = dispatch => {
  return {};
};
export default withRouter(
  connect(
    mapStateToProps,
    mapDispatchToProps
  )(AddItemForm)
);
