import React, { Component } from "react";
import { connect } from "react-redux";
import _ from "lodash";
import CircularProgress from "@material-ui/core/CircularProgress";
import {
  TableBody,
  Table,
  TableHead,
  TableFooter,
  TableRow,
  TableCell,
  Checkbox,
  Menu,
  MenuItem
} from "@material-ui/core";
import { NavLink, withRouter } from "react-router-dom";
import Button from "components/CustomButtons/Button.js";
import { sendRequest } from "utills/util";
import { itemApi } from "constant/api";
import SimpleIcon from "components/simpleIcon/simpleIcon";
import { SimpleMenu } from "components/Menus";
import Cookies from "universal-cookie";

const cookies = new Cookies();

class ItemListComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      items: []
    };
  }
  deleteItem(id, index) {
    let { items } = _.cloneDeep(this.state);
    items[index].isLoading = true;
    this.setState({ items });
    let thenFn = res => {
      items[index].isLoading = false;
      this.setState({ items }, () => {
        this.setState({ items: res && res.data });
      });
      console.log(res);
    };
    let errorFn = error => {
      items[index].isLoading = false;
      this.setState({ items });
      console.log(error);
    };
    sendRequest(itemApi.deleteItem, {
      id,
      success: { fn: thenFn },
      error: { fn: errorFn }
    });
  }
  handleMenuVisible(isMenuOpen, index) {
    let newItems = this.state.items;
    newItems[index].isMenuOpen = isMenuOpen;
    this.setState({ items: newItems });
  }
  componentDidMount() {
    this.setState({ isLoading: true });
    sendRequest(itemApi.getItems, {
      distributorId: cookies.get("distributorId"),
      success: {
        fn: res => {
          this.setState({ isLoading: false });
          console.log(res);
          this.setState({ items: res.data });
        }
      },
      error: {
        fn: error => {
          this.setState({ isLoading: false });
          console.log(error);
        }
      }
    });
  }
  render() {
    let { items, isLoading } = this.state;
    let { history } = this.props;
    return (
      <div>
        {isLoading ? (
          <CircularProgress color="secondary" />
        ) : (
          <div
            style={{
              overflowX: "auto",
              overflowY: "auto",
              height: (window.innerHeight * 70) / 100
            }}
          >
            <Table>
              <TableHead>
                <TableCell>Index</TableCell>
                <TableCell>Thumbnail</TableCell>
                <TableCell>Name</TableCell>
                <TableCell>Alt Name</TableCell>
                <TableCell>Category</TableCell>
                <TableCell>Price(₹)</TableCell>
                <TableCell>Unit</TableCell>
                <TableCell>discount(%)</TableCell>
                <TableCell>Inventory</TableCell>
                <TableCell>Is Featured?</TableCell>
                <TableCell>Options</TableCell>
              </TableHead>
              <TableBody>
                {_.map(items, (item, index) => (
                  <TableRow>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell>
                      <img
                        src={item.imageUrls[0]}
                        style={{ width: "100px", height: "100px" }}
                      />
                    </TableCell>
                    <TableCell>{item.name}</TableCell>
                    <TableCell>{item.altName}</TableCell>
                    <TableCell>{item.category}</TableCell>
                    <TableCell>{item.price}</TableCell>
                    <TableCell>{item.unit}</TableCell>
                    <TableCell>{item.discount}%</TableCell>
                    <TableCell>{item.inventory}</TableCell>
                    <TableCell>
                      <Checkbox checked={item.isFeatured} />
                    </TableCell>
                    <TableCell>
                      {item.isLoading ? (
                        <CircularProgress color="secondary" />
                      ) : (
                        <SimpleMenu
                          items={[
                            {
                              label: "Edit",
                              onClick: () => {
                                history.push(`/admin/addItem/${item._id}`);
                              }
                            },
                            {
                              label: "Delete",
                              onClick: () => {
                                this.deleteItem(item._id, index);
                              }
                            }
                          ]}
                        />
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
        <NavLink to="/admin/addItem">
          <Button color={"primary"}>Add Item</Button>
        </NavLink>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {};
};
const mapDispatchToProps = dispatch => {
  return {};
};
export default withRouter(
  connect(
    mapStateToProps,
    mapDispatchToProps
  )(ItemListComponent)
);
