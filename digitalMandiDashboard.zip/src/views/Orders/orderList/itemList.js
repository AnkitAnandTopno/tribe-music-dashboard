import React from "react";
import { sendRequest } from "utills/util";
import { userApi } from "constant/api";
import {
  TableBody,
  Table,
  TableCell,
  TableRow,
  TableHead,
  TableFooter,
  CircularProgress
} from "@material-ui/core";
import { itemApi } from "constant/api";
import _ from "lodash";

class ItemList extends React.Component {
  constructor(props) {
    super(props);
    this.state = { itemList: [] };
  }
  componentDidMount() {
    let { itemList } = this.props;
    this.setState({ isLoading: true });
    let thenFn = res => {
      this.setState({ itemList: res && res.data, isLoading: false });
    };
    let errorFn = error => {
      alert("Something Went Wrong!");
      this.setState({ isLoading: false });
    };
    sendRequest(itemApi.orderItemList, {
      itemList: itemList || [],
      success: { fn: thenFn },
      error: { fn: errorFn }
    });
  }
  render() {
    let { itemList, isLoading } = this.state;
    return (
      <div>
        {isLoading ? (
          <CircularProgress color="secondary" />
        ) : (
          <div>
            <Table>
              <TableHead>
                <TableCell>Index</TableCell>
                <TableCell>Item</TableCell>
                <TableCell>Name</TableCell>
                <TableCell>Category</TableCell>
                <TableCell>Price</TableCell>
                <TableCell>Unit</TableCell>
                <TableCell>Count per unit</TableCell>
                <TableCell>Total</TableCell>
              </TableHead>
              <TableBody>
                {_.map(itemList, (item, index) => {
                  let cost =
                    item.price * item.count -
                    item.price * (item.discount / 100) * item.count;
                  return (
                    <TableRow>
                      <TableCell>{index + 1}</TableCell>
                      <TableCell>
                        <img
                          src={item.imageUrls[0]}
                          style={{ width: "100px", height: "100px" }}
                        />
                      </TableCell>
                      <TableCell>{item.name}</TableCell>
                      <TableCell>{item.category}</TableCell>
                      <TableCell>{item.price}</TableCell>
                      <TableCell>{`${item.unit}`}</TableCell>
                      <TableCell>{item.count}</TableCell>
                      <TableCell>{`${cost}`}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
              <TableFooter>
                <TableCell>Total</TableCell>
                <TableCell>{`${itemList.length} items`}</TableCell>
                <TableCell></TableCell>
                <TableCell></TableCell>
                <TableCell></TableCell>
                <TableCell></TableCell>
                <TableCell></TableCell>
                <TableCell>
                  {_.sumBy(itemList, (item, index) => {
                    let cost =
                      item.price * item.count -
                      item.price * (item.discount / 100) * item.count;

                    return cost;
                  })}
                </TableCell>
              </TableFooter>
            </Table>
          </div>
        )}
      </div>
    );
  }
}

export default ItemList;
