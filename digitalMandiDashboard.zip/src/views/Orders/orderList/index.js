import React, { Component } from "react";
import { connect } from "react-redux";
import _ from "lodash";
import CircularProgress from "@material-ui/core/CircularProgress";
import {
  TableBody,
  Table,
  TableCell,
  TableHead,
  TableFooter,
  TableRow,
  Checkbox,
  Card,
  Menu,
  MenuItem
} from "@material-ui/core";

import Modal from "@material-ui/core/Modal";
import Backdrop from "@material-ui/core/Backdrop";
import { NavLink, withRouter } from "react-router-dom";
import Button from "components/CustomButtons/Button.js";
import { sendRequest } from "utills/util";
import { itemApi } from "constant/api";
import SimpleIcon from "components/simpleIcon/simpleIcon";
import { SimpleMenu } from "components/Menus";
import Cookies from "universal-cookie";
import { orderApi } from "constant/api";
import moment from "moment";
import UserInfo from "./userInfo";
import ItemList from "./itemList";

const cookies = new Cookies();

class OrderListComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      orders: []
    };
  }
  deleteItem(id, index) {
    let { items } = _.cloneDeep(this.state);
    items[index].isLoading = true;
    this.setState({ items });
    let thenFn = res => {
      items[index].isLoading = false;
      this.setState({ items }, () => {
        this.setState({ items: res && res.data });
      });
      console.log(res);
    };
    let errorFn = error => {
      items[index].isLoading = false;
      this.setState({ items });
      console.log(error);
    };
    sendRequest(itemApi.deleteItem, {
      id,
      success: { fn: thenFn },
      error: { fn: errorFn }
    });
  }
  handleMenuVisible(isMenuOpen, index) {
    let newItems = this.state.items;
    newItems[index].isMenuOpen = isMenuOpen;
    this.setState({ items: newItems });
  }
  componentDidMount() {
    this.setState({ isLoading: true });
    sendRequest(orderApi.getOrders, {
      distributorId: cookies.get("distributorId"),
      success: {
        fn: res => {
          this.setState({ isLoading: false });
          console.log(res);
          this.setState({ orders: res.data });
        }
      },
      error: {
        fn: error => {
          this.setState({ isLoading: false });
          console.log(error);
        }
      }
    });
  }
  handleUserInfoVisible(openUserInfo) {
    this.setState({ openUserInfo });
  }
  handleItemListVisible(openItemList) {
    this.setState({ openItemList });
  }
  render() {
    let {
      orders,
      isLoading,
      openUserInfo,
      openItemList,
      activeItemList,
      activeUserId
    } = this.state;
    let { history } = this.props;
    return (
      <div>
        <Modal
          aria-labelledby="transition-modal-title"
          aria-describedby="transition-modal-description"
          open={openUserInfo}
          onClose={() => this.handleUserInfoVisible(false)}
          closeAfterTransition
          BackdropComponent={Backdrop}
          BackdropProps={{
            timeout: 500
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              height: "100%",
              width: "100%"
            }}
          >
            <Card style={{ width: "fit-content", padding: 20 }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center"
                }}
              >
                <UserInfo userId={activeUserId} />

                <Button
                  onClick={() => {
                    this.handleUserInfoVisible(false);
                  }}
                  color="primary"
                >
                  OK
                </Button>
              </div>
            </Card>
          </div>
        </Modal>
        <Modal
          aria-labelledby="transition-modal-title"
          aria-describedby="transition-modal-description"
          open={openItemList}
          onClose={() => this.handleItemListVisible(false)}
          closeAfterTransition
          BackdropComponent={Backdrop}
          BackdropProps={{
            timeout: 500
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              height: "100%",
              width: "100%"
            }}
          >
            <Card style={{ width: "fit-content", padding: 20 }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center"
                }}
              >
                <ItemList itemList={activeItemList} />

                <Button
                  onClick={() => {
                    this.handleItemListVisible(false);
                  }}
                  color="primary"
                >
                  OK
                </Button>
              </div>
            </Card>
          </div>
        </Modal>
        {isLoading ? (
          <CircularProgress color="secondary" />
        ) : (
          <div
            style={{
              overflowX: "auto",
              overflowY: "auto",
              height: (window.innerHeight * 70) / 100
            }}
          >
            <Table>
              <TableHead>
                <TableCell>Index</TableCell>
                <TableCell>Order Number</TableCell>
                <TableCell>Date</TableCell>
                <TableCell>Is Delivery Boy Assigned?</TableCell>
                <TableCell>Is Delivered?</TableCell>
                <TableCell>Is Cancelled?</TableCell>
                <TableCell>User Info</TableCell>
                <TableCell>Item List</TableCell>
              </TableHead>
              <TableBody>
                {_.map(orders, (item, index) => (
                  <TableRow>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell>{item.orderNumber}</TableCell>
                    <TableCell>
                      {moment(item.date, "YYYY-MM-DD").format("DD/MM/YYYY")}
                    </TableCell>
                    <TableCell>
                      <Checkbox checked={item.isAssigned} />
                    </TableCell>
                    <TableCell>
                      <Checkbox checked={item.isDelivered} />
                    </TableCell>
                    <TableCell>
                      <Checkbox checked={item.isCancelled} />
                    </TableCell>
                    <TableCell>
                      <Button
                        onClick={() => {
                          this.setState({ activeUserId: item.userId }, () => {
                            this.handleUserInfoVisible(true);
                          });
                        }}
                        color="primary"
                      >
                        See User Info
                      </Button>
                    </TableCell>
                    <TableCell>
                      <Button
                        onClick={() => {
                          this.setState(
                            { activeItemList: item.itemList },
                            () => {
                              this.handleItemListVisible(true);
                            }
                          );
                        }}
                        color="primary"
                      >
                        See Item List
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {};
};
const mapDispatchToProps = dispatch => {
  return {};
};
export default withRouter(
  connect(
    mapStateToProps,
    mapDispatchToProps
  )(OrderListComponent)
);
