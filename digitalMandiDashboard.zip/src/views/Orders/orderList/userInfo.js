import React from "react";
import { sendRequest } from "utills/util";
import { userApi } from "constant/api";
import { CircularProgress } from "@material-ui/core";

class UserInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = { userInfo: {} };
  }
  componentDidMount() {
    let { userId } = this.props;
    this.setState({ isLoading: true });
    let thenFn = res => {
      this.setState({ userInfo: res && res.data, isLoading: false });
    };
    let errorFn = error => {
      alert("Something Went Wrong!");
      this.setState({ isLoading: false });
    };
    sendRequest(userApi.getUserInfo, {
      id: userId,
      success: { fn: thenFn },
      error: { fn: errorFn }
    });
  }
  render() {
    let { userInfo, isLoading } = this.state;
    return (
      <div>
        {isLoading ? (
          <CircularProgress color="secondary" />
        ) : (
          <div>
            <img
              src={userInfo.profilePicUrl}
              style={{ width: "100px", height: "100px" }}
            />
            <h5>Name</h5>
            <span>{userInfo.userName}</span>
            <h5>Phone Number</h5>
            <span>{userInfo.phoneNumber}</span>
            <h5>Alternate Phone Number</h5>
            <span>{userInfo.altPhoneNumber}</span>
            <h5>Address</h5>
            <span>
              {userInfo.address &&
                userInfo.address[0] &&
                userInfo.address[0].addressText}
            </span>
          </div>
        )}
      </div>
    );
  }
}

export default UserInfo;
