import TableComponent from "./tableComponent";

export { TableComponent };
