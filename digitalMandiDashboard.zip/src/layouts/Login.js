import React from "react";
import Cookies from "universal-cookie";
import Card from "../components/Card/Card";
import CardBody from "../components/Card/CardBody.js";
import CardFooter from "../components/Card/CardFooter.js";
import CardHeader from "../components/Card/CardHeader.js";
import Button from "../components/CustomButtons/Button.js";
import CustomInput from "../components/CustomInput/CustomInput";
import { sendRequest } from "../utills/util";
import { authApi } from "../constant/api";
import { CircularProgress } from "@material-ui/core";
import { withRouter } from "react-router-dom";

const cookies = new Cookies();

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      distributorId: "",
      password: ""
    };
  }
  onSignIn() {
    let { distributorId, password } = this.state;
    let { history } = this.props;
    this.setState({ isLoading: true });
    const thenFn = res => {
      this.setState({ isLoading: false });
      let data = res && res.data;
      if (data && data.distributorId && data.distributorId !== "") {
        cookies.set("distributorId", data.distributorId, {
          path: "/",
          expires: new Date(Date.now() + 2592000)
        });
        history.push("/admin/dashboard");
      } else {
        alert("Something Went wrong. Please try again.");
      }
    };
    const errorFn = error => {
      this.setState({ isLoading: false });
      alert(error);
    };
    sendRequest(authApi.signIn, {
      distributorId,
      password,
      success: { fn: thenFn },
      error: { fn: errorFn }
    });
  }
  componentWillMount() {
    let { history } = this.props;
    if (cookies.get("distributorId") && cookies.get("distributorId") !== "") {
      history.push("/admin/dashboard");
    }
  }
  render() {
    let { distributorId, password, isLoading } = this.state;
    return (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center"
        }}
      >
        <div style={{ width: 400 }}>
          <Card>
            <CardHeader color="primary">
              <p>Digital Mandi</p>
              <h3>Dashboard Login</h3>
            </CardHeader>
            {isLoading ? (
              <CardBody>
                <CircularProgress color="primary" />
              </CardBody>
            ) : (
              <CardBody>
                <CustomInput
                  labelText="Distributor Id"
                  id="distributorId"
                  formControlProps={{
                    fullWidth: true
                  }}
                  inputProps={{
                    value: distributorId,
                    onChange: e => {
                      this.setState({ distributorId: e.target.value });
                    }
                  }}
                />
                <CustomInput
                  labelText="Password"
                  id="password"
                  formControlProps={{
                    fullWidth: true
                  }}
                  inputProps={{
                    type: "password",
                    value: password,
                    onChange: e => {
                      this.setState({ password: e.target.value });
                    }
                  }}
                />
              </CardBody>
            )}
            <CardFooter>
              <Button
                disabled={isLoading}
                color="primary"
                onClick={() => {
                  this.onSignIn();
                }}
              >
                Sign In
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    );
  }
}

export default withRouter(Login);
