export const GET_REQUEST = "get";
export const POST_REQUEST = "post";

const ACCOUNT = "auth";
const DISTRIBUTOR = "distributor";
const UPLOAD = "fileUpload";
const FEEDBACK = "feedbacks";
const ITEM = "item";
const RECIPE = "recipe";
const INVENTORY = "inventory";
const ORDER = "order";
const USER = "user";

const FIREBASE = "firebase";

const authApi = {
  signIn: {
    type: POST_REQUEST,
    path: `${DISTRIBUTOR}/signIn`
  },
  logOut: {
    type: POST_REQUEST,
    path: `${ACCOUNT}/logout`
  },
  sendNotification: {
    type: POST_REQUEST,
    path: `${FIREBASE}`
  },
  getFeedbacks: {
    type: GET_REQUEST,
    path: `${FEEDBACK}`
  }
};
const inventoryApi = {
  updateInventory: {
    type: POST_REQUEST,
    path: `${INVENTORY}/updateInventory`
  }
};
const orderApi = {
  getOrders: {
    type: GET_REQUEST,
    path: `${ORDER}`
  }
};
const userApi = {
  getUserInfo: {
    type: GET_REQUEST,
    path: `${USER}`
  }
};
const itemApi = {
  getItems: {
    type: GET_REQUEST,
    path: `${ITEM}`
  },
  orderItemList: {
    type: POST_REQUEST,
    path: `${ITEM}/orderItemList`
  },
  addItem: {
    type: POST_REQUEST,
    path: `${ITEM}`
  },
  updateItem: {
    type: POST_REQUEST,
    path: `${ITEM}/update`
  },
  addMultipleItems: {
    type: POST_REQUEST,
    path: `${ITEM}/addMultipleItems`
  },
  deleteItem: {
    type: POST_REQUEST,
    path: `${ITEM}/delete`
  }
};
const recipeApi = {
  getRecipe: {
    type: GET_REQUEST,
    path: `${RECIPE}`
  },
  addRecipe: {
    type: POST_REQUEST,
    path: `${RECIPE}`
  },
  uploadRecipeImage: {
    type: POST_REQUEST,
    path: `${UPLOAD}/recipeImage`
  }
};
const fileApi = {
  getImages: { type: GET_REQUEST, path: `${UPLOAD}/getImages` },
  uploadImage: { type: POST_REQUEST, path: `${UPLOAD}/uploadImage` }
};
export {
  authApi,
  fileApi,
  itemApi,
  recipeApi,
  inventoryApi,
  orderApi,
  userApi
};
