import SimpleMenu from "./simpleMenu.js";

export { SimpleMenu };
